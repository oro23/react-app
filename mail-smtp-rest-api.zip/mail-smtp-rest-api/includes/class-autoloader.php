<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Autoloader
{
    /**
     * Register SPL autoloader
     */
    public static function register(): void
    {
        spl_autoload_register([__CLASS__, 'autoload']);
    }

    /**
     * Load MSRA classes automatically
     */
    public static function autoload(string $class): void
    {
        if (strpos($class, 'MSRA_') !== 0) {
            return;
        }

        $class = str_replace('MSRA_', '', $class);

        $file = 'class-' . strtolower(str_replace('_', '-', $class)) . '.php';

        $path = MSRA_PLUGIN_DIR . 'includes/' . $file;

        if (file_exists($path)) {
            require_once $path;
        }
    }
}