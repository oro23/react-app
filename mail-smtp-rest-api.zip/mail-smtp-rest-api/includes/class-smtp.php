<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_SMTP
{
    public function __construct()
    {
        add_action('phpmailer_init', [$this, 'configure_smtp']);
        add_filter('wp_mail_from', [$this, 'from_email']);
        add_filter('wp_mail_from_name', [$this, 'from_name']);
    }

    /**
     * Configure PHPMailer SMTP settings
     *
     * @param PHPMailer $phpmailer
     */
    // public function configure_smtp($phpmailer): void
    // {
    //     $enabled = MSRA_Utils::setting('smtp_enabled', true);

    //     if (!$enabled) {
    //         return;
    //     }

    //     $from_email = get_option('msra_from_email');
    //     $from_name = get_option('msra_from_name');

    //     if (is_email($from_email)) {
    //         $phpmailer->From = $from_email;
    //         $phpmailer->FromName = $from_name ?: 'WordPress';
    //     } else {
    //         $phpmailer->From = 'no-reply@' . parse_url(home_url(), PHP_URL_HOST);
    //         $phpmailer->FromName = get_bloginfo('name');
    //     }

    //     $host = get_option('msra_smtp_host');
    //     $port = get_option('msra_smtp_port', 587);
    //     $user = get_option('msra_smtp_username');
    //     $pass = get_option('msra_smtp_password');
    //     $encryption = get_option('msra_smtp_encryption', 'tls');

    //     // 🔥 SAFE FROM EMAIL HANDLING (IMPORTANT FIX)
    //     // $from_email = get_option('msra_from_email');
    //     // $from_name = get_option('msra_from_name');

    //     // Validate email
    //     // if (!is_email($from_email)) {
    //     //     $from_email = 'no-reply@' . parse_url(home_url(), PHP_URL_HOST);
    //     // }

    //     // if (empty($from_name)) {
    //     //     $from_name = get_bloginfo('name');
    //     // }

    //     // Force SMTP mode
    //     $phpmailer->isMail();

    //     if (empty($host)) {
    //         error_log('MSRA: SMTP host missing');
    //         throw new Exception('SMTP host is not configured');
    //     }

    //     $phpmailer->Host = $host;
    //     $phpmailer->Port = (int) $port;
    //     $phpmailer->SMTPAuth = !empty($user);

    //     if (!empty($user)) {
    //         $phpmailer->Username = $user;
    //         $phpmailer->Password = $pass;
    //     }

    //     // Encryption
    //     if ($encryption === 'ssl') {
    //         $phpmailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
    //     } elseif ($encryption === 'tls') {
    //         $phpmailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    //     }

    //     // Timeout
    //     $phpmailer->Timeout = 30;

    //     // 🔥 SAFE ASSIGNMENT (AFTER VALIDATION)
    //     $phpmailer->From = $from_email;
    //     $phpmailer->FromName = $from_name;

    //     // Debug
    //     if (defined('WP_DEBUG') && WP_DEBUG) {
    //         $phpmailer->SMTPDebug = 0;
    //     }
    // }

    public function configure_smtp($phpmailer)
    {
        $host = get_option('msra_smtp_host');
        $port = (int) get_option('msra_smtp_port', 587);
        $user = get_option('msra_smtp_username');
        $pass = get_option('msra_smtp_password');
        $encryption = get_option('msra_smtp_encryption', 'tls');

        if (empty($host)) {
            error_log('MSRA: SMTP host missing');
            return;
        }

        $phpmailer->isSMTP();
        // $phpmailer->isMail();

        $phpmailer->Host = $host;
        $phpmailer->Port = $port;
        $phpmailer->SMTPAuth = !empty($user);

        if (!empty($user)) {
            $phpmailer->Username = $user;
            $phpmailer->Password = $pass;
        }

        if ($encryption === 'ssl') {
            $phpmailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($encryption === 'tls') {
            $phpmailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $phpmailer->SMTPSecure = false;
        }

        $from_email = get_option('msra_from_email');
        $from_name = get_option('msra_from_name');

        if (is_email($from_email)) {
            $phpmailer->From = $from_email;
        }

        if (!empty($from_name)) {
            $phpmailer->FromName = $from_name;
        }

        $phpmailer->Timeout = 30;
    }

    /**
     * Override From Email
     */
    public function from_email(string $email): string
    {
        $custom = MSRA_Utils::setting('from_email', '');

        return !empty($custom)
            ? sanitize_email($custom)
            : $email;
    }

    /**
     * Override From Name
     */
    public function from_name(string $name): string
    {
        $custom = MSRA_Utils::setting('from_name', '');

        return !empty($custom)
            ? sanitize_text_field($custom)
            : $name;
    }

    /**
     * Test SMTP connection
     */
    public function test_connection(): bool
    {
        try {

            $phpmailer = new PHPMailer(true);

            $this->configure_smtp($phpmailer);

            return $phpmailer->smtpConnect();

        } catch (Exception $e) {
            return false;
        }
    }
}