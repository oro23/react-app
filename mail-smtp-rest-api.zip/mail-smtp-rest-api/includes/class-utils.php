<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Utils
{
    public static function settings()
    {
        return get_option(
            'msra_settings',
            []
        );
    }

    public static function setting($key, $default = '')
    {
        $settings = self::settings();

        return $settings[$key] ?? $default;
    }

    function msra_log($message, $context = [])
    {
        if (!defined('WP_DEBUG') || WP_DEBUG !== true) {
            return;
        }

        $log = '[MSRA] ' . $message;

        if (!empty($context)) {
            $log .= ' | ' . wp_json_encode($context);
        }

        error_log($log);
    }

    public static function log($message, $context = [])
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {

            $log = '[MSRA] ' . $message;

            if (!empty($context)) {
                $log .= ' | ' . wp_json_encode($context);
            }

            error_log($log);
        }
    }
}