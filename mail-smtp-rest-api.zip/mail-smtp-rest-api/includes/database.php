<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Database
{
    public static function install(): void
    {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        self::create_logs_table($charset);

        self::create_queue_table($charset);

        self::create_api_table($charset);
    }

    private static function create_logs_table(string $charset): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'mail_smtp_logs';

        $sql = "

CREATE TABLE {$table}

(

id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

to_email LONGTEXT NOT NULL,

subject TEXT,

body LONGTEXT,

status VARCHAR(20),

response LONGTEXT,

execution_time FLOAT DEFAULT 0,

created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

PRIMARY KEY(id),

KEY status(status),

KEY created_at(created_at)

)

{$charset};

";

        dbDelta($sql);
    }

    private static function create_queue_table(string $charset): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'mail_smtp_queue';

        $sql = "

CREATE TABLE {$table}

(

id BIGINT UNSIGNED AUTO_INCREMENT,

payload LONGTEXT,

attempts INT DEFAULT 0,

status VARCHAR(20),

next_retry DATETIME,

created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

PRIMARY KEY(id),

KEY status(status),

KEY next_retry(next_retry)

)

{$charset};

";

        dbDelta($sql);
    }

    private static function create_api_table(string $charset): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'mail_smtp_api_keys';

        $sql = "

CREATE TABLE {$table}

(

id BIGINT UNSIGNED AUTO_INCREMENT,

name VARCHAR(200),

api_key_hash VARCHAR(255),

status TINYINT DEFAULT 1,

last_used DATETIME NULL,

created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

PRIMARY KEY(id),

KEY status(status)

)

{$charset};

";

        dbDelta($sql);
    }
}