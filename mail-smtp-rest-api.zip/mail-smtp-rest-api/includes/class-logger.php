<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Logger
{
    /**
     * Log table.
     *
     * @var string
     */
    private string $table;

    /**
     * Constructor.
     */
    public function __construct()
    {
        global $wpdb;

        $this->table = $wpdb->prefix . 'mail_smtp_logs';
    }

    /**
     * Write a log entry.
     *
     * @param array $data
     * @return bool
     */
    public function log(array $data): bool
    {
        global $wpdb;

        $defaults = [
            'to_email' => '',
            'subject' => '',
            'body' => '',
            'status' => 'success',
            'response' => '',
            'execution_time' => 0,
            'created_at' => current_time('mysql'),
        ];

        $data = wp_parse_args($data, $defaults);

        $result = $wpdb->insert(
            $this->table,
            [
                'to_email' => maybe_serialize($data['to_email']),
                'subject' => $data['subject'],
                'body' => $data['body'],
                'status' => $data['status'],
                'response' => $data['response'],
                'execution_time' => (float) $data['execution_time'],
                'created_at' => $data['created_at'],
            ],
            [
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%f',
                '%s',
            ]
        );

        return $result !== false;
    }

    /**
     * Log successful email.
     *
     * @param array $mail
     * @param float $execution_time
     * @return bool
     */
    public function success(array $mail, float $execution_time = 0): bool
    {
        return $this->log([
            'to_email' => $mail['to'] ?? '',
            'subject' => $mail['subject'] ?? '',
            'body' => $mail['message'] ?? '',
            'status' => 'success',
            'response' => 'Mail sent successfully.',
            'execution_time' => $execution_time,
        ]);
    }

    /**
     * Log failed email.
     *
     * @param array  $mail
     * @param string $error
     * @param float  $execution_time
     * @return bool
     */
    public function failed(
        array $mail,
        string $error,
        float $execution_time = 0
    ): bool {

        return $this->log([
            'to_email' => $mail['to'] ?? '',
            'subject' => $mail['subject'] ?? '',
            'body' => $mail['message'] ?? '',
            'status' => 'failed',
            'response' => $error,
            'execution_time' => $execution_time,
        ]);
    }

    /**
     * Log queued email.
     *
     * @param array $mail
     * @return bool
     */
    public function queued(array $mail): bool
    {
        return $this->log([
            'to_email' => $mail['to'] ?? '',
            'subject' => $mail['subject'] ?? '',
            'body' => $mail['message'] ?? '',
            'status' => 'queued',
            'response' => 'Email added to queue.',
        ]);
    }

    /**
     * Log REST request.
     *
     * @param string $endpoint
     * @param string $status
     * @param string $message
     * @return bool
     */
    public function rest(
        string $endpoint,
        string $status,
        string $message
    ): bool {

        return $this->log([
            'to_email' => '',
            'subject' => 'REST: ' . $endpoint,
            'body' => '',
            'status' => $status,
            'response' => $message,
        ]);
    }

    /**
     * Get log by ID.
     *
     * @param int $id
     * @return object|null
     */
    public function get(int $id)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$this->table}
                 WHERE id=%d",
                $id
            )
        );
    }

    /**
     * Get recent logs.
     *
     * @param int $limit
     * @return array
     */
    public function recent(int $limit = 20): array
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$this->table}
                 ORDER BY id DESC
                 LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Count logs.
     *
     * @return int
     */
    public function count(): int
    {
        global $wpdb;

        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$this->table}"
        );
    }

    /**
     * Delete log.
     *
     * @param int $id
     * @return bool
     */
    public function delete(int $id): bool
    {
        global $wpdb;

        $deleted = $wpdb->delete(
            $this->table,
            [
                'id' => $id,
            ],
            [
                '%d',
            ]
        );

        return $deleted !== false;
    }

    /**
     * Clear all logs.
     *
     * @return bool
     */
    public function clear(): bool
    {
        global $wpdb;

        $result = $wpdb->query(
            "TRUNCATE TABLE {$this->table}"
        );

        return $result !== false;
    }
}