<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_REST
{
    private MSRA_Auth $auth;
    private MSRA_Rate_Limit $rate;
    private MSRA_Mail $mail;
    private MSRA_Queue $queue;
    private MSRA_Logger $logger;

    public function __construct()
    {
        $this->auth = new MSRA_Auth();
        $this->rate = new MSRA_Rate_Limit();
        $this->mail = new MSRA_Mail();
        $this->queue = new MSRA_Queue();
        $this->logger = new MSRA_Logger();

        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Register REST routes
     */
    public function register_routes(): void
    {
        register_rest_route('mail-smtp/v1', '/send', [
            'methods' => 'POST',
            'callback' => [$this, 'send_email'],
            'permission_callback' => [$this, 'permission_check'],
        ]);

        register_rest_route('mail-smtp/v1', '/status', [
            'methods' => 'GET',
            'callback' => [$this, 'status'],
            'permission_callback' => [$this, 'permission_check'],
        ]);

        register_rest_route('mail-smtp/v1', '/test', [
            'methods' => 'POST',
            'callback' => [$this, 'test'],
            'permission_callback' => [$this, 'permission_check'],
        ]);

        register_rest_route('mail-smtp/v1', '/queue', [
            'methods' => 'GET',
            'callback' => [$this, 'queue_overview'],
            'permission_callback' => [$this, 'permission_check'],
        ]);
    }

    /**
     * Permission check (Auth + Rate Limit)
     */
    public function permission_check(WP_REST_Request $request)
    {
        $api_key = $request->get_header('X-API-KEY');

        if (empty($api_key)) {
            return new WP_Error('no_key', 'API key missing', ['status' => 401]);
        }

        // Auth
        if (!$this->auth->authenticate()) {
            return new WP_Error('invalid_key', 'Invalid API key', ['status' => 403]);
        }

        // Rate limit
        if (!$this->rate->allow($api_key)) {
            return new WP_Error(
                'rate_limited',
                'Too many requests',
                [
                    'status' => 429,
                    'retry_after' => $this->rate->retry_after($api_key),
                ]
            );
        }

        return true;
    }

    /**
     * Send email endpoint
     */
    public function send_email(WP_REST_Request $request)
    {
        $start = microtime(true);

        $data = $request->get_json_params();

        if (empty($data['to']) || empty($data['subject'])) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Missing required fields: to, subject'
            ], 400);
        }

        // Queue option
        if (!empty($data['queue'])) {

            $queued = $this->queue->add($data);

            $this->logger->rest('/send', 'queued', 'Email queued');

            return new WP_REST_Response([
                'success' => $queued,
                'queued' => true
            ], 200);
        }

        // Send immediately
        $result = $this->mail->send($data);

        $execution = round(microtime(true) - $start, 4);

        if ($result) {

            $this->logger->rest('/send', 'success', 'Email sent');

            return new WP_REST_Response([
                'success' => true,
                'sent' => true,
                'time' => $execution
            ], 200);
        }

        $this->logger->rest('/send', 'failed', 'Email failed');

        return new WP_REST_Response([
            'success' => false,
            'sent' => false,
            'time' => $execution
        ], 500);
    }

    /**
     * System status endpoint
     */
    public function status(WP_REST_Request $request)
    {
        return new WP_REST_Response([
            'status' => 'active',
            'time' => current_time('mysql'),
            'queue_count' => $this->queue->stats(),
        ], 200);
    }

    /**
     * Test SMTP + Mail system
     */
    public function test(WP_REST_Request $request)
    {
        $data = $request->get_json_params();

        $to = $data['to'] ?? get_option('admin_email');

        $sent = $this->mail->send([
            'to' => $to,
            'subject' => 'SMTP Test Email',
            'message' => '<h2>Test successful</h2>',
            'html' => true,
        ]);

        return new WP_REST_Response([
            'success' => $sent
        ], $sent ? 200 : 500);
    }

    /**
     * Queue overview endpoint
     */
    public function queue_overview()
    {
        return new WP_REST_Response(
            $this->queue->stats(),
            200
        );
    }
}