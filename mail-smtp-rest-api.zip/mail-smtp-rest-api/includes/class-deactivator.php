<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Deactivator
{
    public static function deactivate(): void
    {
        wp_clear_scheduled_hook(
            'msra_process_queue'
        );

        flush_rewrite_rules();
    }
}