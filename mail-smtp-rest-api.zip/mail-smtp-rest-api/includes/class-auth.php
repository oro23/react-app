<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Auth
{
    private string $table;

    public function __construct()
    {
        global $wpdb;
        $this->table = $wpdb->prefix . 'mail_smtp_api_keys';
    }

    /**
     * Authenticate request using API key
     */
    public function authenticate(): bool
    {
        $api_key = $this->get_api_key_from_request();

        if (empty($api_key)) {
            return false;
        }

        return $this->verify_key($api_key);
    }

    /**
     * Get API key from request headers
     */
    private function get_api_key_from_request(): string
    {
        $headers = function_exists('getallheaders')
            ? getallheaders()
            : [];

        if (!empty($headers['X-API-KEY'])) {
            return sanitize_text_field($headers['X-API-KEY']);
        }

        if (!empty($_SERVER['HTTP_X_API_KEY'])) {
            return sanitize_text_field(wp_unslash($_SERVER['HTTP_X_API_KEY']));
        }

        return '';
    }

    /**
     * Verify API key against database
     */
    private function verify_key(string $raw_key): bool
    {
        global $wpdb;

        $keys = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, api_key_hash
                 FROM {$this->table}
                 WHERE status = %d",
                1
            )
        );

        if (empty($keys)) {
            return false;
        }

        foreach ($keys as $row) {

            if (password_verify($raw_key, $row->api_key_hash)) {

                $wpdb->update(
                    $this->table,
                    [
                        'last_used' => current_time('mysql'),
                    ],
                    [
                        'id' => $row->id,
                    ]
                );

                return true;
            }
        }

        return false;
    }

    /**
     * Generate API key
     */
    public function generate_key(string $name)
    {
        global $wpdb;

        $name = sanitize_text_field($name);

        if ($name === '') {
            return new WP_Error('invalid_name', 'API key name is required.');
        }

        $plain_key = bin2hex(random_bytes(32));

        $hash = password_hash($plain_key, PASSWORD_DEFAULT);

        $insert = $wpdb->insert(
            $this->table,
            [
                'name' => $name,
                'api_key_hash' => $hash,
                'status' => 1,
                'created_at' => current_time('mysql'),
            ]
        );

        if (!$insert) {
            return new WP_Error('db_error', 'Failed to create API key.');
        }

        return [
            'id' => $wpdb->insert_id,
            'key' => $plain_key, // show only once
        ];
    }

    /**
     * Get all keys
     */
    public function get_keys(): array
    {
        global $wpdb;

        return $wpdb->get_results(
            "SELECT id, name, status, last_used, created_at
             FROM {$this->table}
             ORDER BY id DESC",
            ARRAY_A
        );
    }

    /**
     * Revoke key
     */
    public function revoke_key(int $id): bool
    {
        global $wpdb;

        return $wpdb->update(
            $this->table,
            ['status' => 0],
            ['id' => $id]
        ) !== false;
    }

    /**
     * Delete key
     */
    public function delete_key(int $id): bool
    {
        global $wpdb;

        return $wpdb->delete(
            $this->table,
            ['id' => $id]
        ) !== false;
    }
}