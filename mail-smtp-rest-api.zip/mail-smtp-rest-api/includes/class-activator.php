<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Activator
{
    public static function activate(): void
    {
        require_once MSRA_PLUGIN_DIR . 'includes/database.php';

        MSRA_Database::install();

        self::create_options();

        self::create_cron();

        update_option(
            'msra_version',
            MSRA_VERSION,
            false
        );

        flush_rewrite_rules();

        self::create_api_keys_table_seed();
    }

    private static function create_options(): void
    {
        $defaults = [

            'smtp_host' => '',

            'smtp_port' => 587,

            'smtp_username' => '',

            'smtp_password' => '',

            'smtp_secure' => 'tls',

            'smtp_auth' => 1,

            'from_email' => get_bloginfo('admin_email'),

            'from_name' => get_bloginfo('name'),

            'timeout' => 30,

            'keep_alive' => 0,

            'debug' => 0,

            'rate_limit' => 100,

            'queue_retry' => 3

        ];

        add_option(
            'msra_settings',
            $defaults
        );
    }

    private static function create_cron(): void
    {
        if (!wp_next_scheduled('msra_process_queue')) {

            wp_schedule_event(

                time(),

                'five_minutes',

                'msra_process_queue'

            );
        }
    }

    public static function create_api_keys_table_seed(): void
    {
        global $wpdb;

        $table = $wpdb->prefix . 'mail_smtp_api_keys';

        // Only seed if empty
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");

        if ($count > 0) {
            return;
        }

        // Generate secure API key
        $raw_key = 'msra_' . bin2hex(random_bytes(24));

        // Hash it (secure storage)
        $hashed = hash('sha256', $raw_key);

        $wpdb->insert(
            $table,
            [
                'name' => 'Default API Key',
                'api_key_hash' => $hashed,
                'status' => 'active',
                'last_used' => null,
                'created_at' => current_time('mysql'),
            ],
            [
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            ]
        );

        // Store raw key temporarily (admin only notice)
        update_option('msra_default_api_key', $raw_key);
    }
}