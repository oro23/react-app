<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Cron
{
    /**
     * Queue table.
     *
     * @var string
     */
    private string $table;

    /**
     * Constructor.
     */
    public function __construct()
    {
        global $wpdb;

        $this->table = $wpdb->prefix . 'mail_smtp_queue';

        add_action(
            'msra_process_queue',
            [$this, 'process_queue']
        );
    }

    /**
     * Process queued emails.
     *
     * @return void
     */
    public function process_queue(): void
    {
        global $wpdb;

        $retry_limit = (int) MSRA_Utils::setting('queue_retry', 3);

        $items = $wpdb->get_results(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$this->table}
                WHERE status = %s
                  AND (
                        next_retry IS NULL
                        OR next_retry <= %s
                  )
                ORDER BY id ASC
                LIMIT %d
                ",
                'pending',
                current_time('mysql'),
                20
            )
        );

        if (empty($items)) {
            return;
        }

        $mailer = new MSRA_Mail();

        foreach ($items as $item) {

            $wpdb->update(
                $this->table,
                [
                    'status' => 'processing',
                ],
                [
                    'id' => $item->id,
                ],
                [
                    '%s',
                ],
                [
                    '%d',
                ]
            );

            $payload = json_decode($item->payload, true);

            if (!is_array($payload)) {

                $this->mark_failed(
                    $item->id,
                    $item->attempts + 1,
                    $retry_limit
                );

                continue;
            }

            $sent = $mailer->send($payload);

            if ($sent === true) {

                $wpdb->update(
                    $this->table,
                    [
                        'status' => 'completed',
                    ],
                    [
                        'id' => $item->id,
                    ],
                    [
                        '%s',
                    ],
                    [
                        '%d',
                    ]
                );

                continue;
            }

            $this->mark_failed(
                $item->id,
                $item->attempts + 1,
                $retry_limit
            );
        }
    }

    /**
     * Update queue item after a failed attempt.
     *
     * @param int $id
     * @param int $attempts
     * @param int $retry_limit
     *
     * @return void
     */
    private function mark_failed(
        int $id,
        int $attempts,
        int $retry_limit
    ): void {

        global $wpdb;

        if ($attempts >= $retry_limit) {

            $wpdb->update(
                $this->table,
                [
                    'status' => 'failed',
                    'attempts' => $attempts,
                ],
                [
                    'id' => $id,
                ],
                [
                    '%s',
                    '%d',
                ],
                [
                    '%d',
                ]
            );

            return;
        }

        $next_retry = gmdate(
            'Y-m-d H:i:s',
            time() + (5 * MINUTE_IN_SECONDS)
        );

        $wpdb->update(
            $this->table,
            [
                'status' => 'pending',
                'attempts' => $attempts,
                'next_retry' => $next_retry,
            ],
            [
                'id' => $id,
            ],
            [
                '%s',
                '%d',
                '%s',
            ],
            [
                '%d',
            ]
        );
    }

    /**
     * Run queue processing immediately.
     *
     * Useful for manual testing.
     *
     * @return void
     */
    public function run_now(): void
    {
        $this->process_queue();
    }
}