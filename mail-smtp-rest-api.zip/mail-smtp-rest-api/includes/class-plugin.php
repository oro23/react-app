<?php

if (!defined('ABSPATH')) {
    exit;
}

final class MSRA_Plugin
{
    private static ?MSRA_Plugin $instance = null;

    public static function instance(): MSRA_Plugin
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function init_admin()
    {
        new MSRA_Admin();
    }

    private function __construct()
    {
        $this->load();
        // add_action('plugins_loaded', [$this, 'init_admin']);
        new MSRA_REST();
    }

    private function load(): void
    {
        new MSRA_Loader();
    }

    private function __clone()
    {
    }

    public function __wakeup()
    {
        throw new Exception('Cannot unserialize singleton.');
    }

}