<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Mail
{
    /**
     * Logger instance.
     *
     * @var MSRA_Logger
     */
    private MSRA_Logger $logger;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->logger = new MSRA_Logger();
    }

    /**
     * Send an email.
     *
     * Payload:
     *
     * [
     *   'to' => [],
     *   'subject' => '',
     *   'message' => '',
     *   'html' => true,
     *   'cc' => [],
     *   'bcc' => [],
     *   'reply_to' => '',
     *   'attachments' => [],
     *   'headers' => []
     * ]
     *
     * @param array $payload
     * @return bool
     */
    public function send(array $payload): bool
    {
        $start = microtime(true);

        if (empty($payload['to'])) {

            $this->logger->failed(
                $payload,
                __('Recipient is required.', 'mail-smtp-rest-api')
            );

            return false;
        }

        if (empty($payload['subject'])) {

            $this->logger->failed(
                $payload,
                __('Subject is required.', 'mail-smtp-rest-api')
            );

            return false;
        }

        $to = (array) $payload['to'];

        $subject = sanitize_text_field($payload['subject']);

        $message = $payload['message'] ?? '';

        $headers = [];

        /*
        |--------------------------------------------------------------------------
        | Content Type
        |--------------------------------------------------------------------------
        */

        if (!empty($payload['html'])) {

            $headers[] = 'Content-Type: text/html; charset=UTF-8';

        } else {

            $headers[] = 'Content-Type: text/plain; charset=UTF-8';
        }

        /*
        |--------------------------------------------------------------------------
        | CC
        |--------------------------------------------------------------------------
        */

        if (!empty($payload['cc'])) {

            foreach ((array) $payload['cc'] as $cc) {

                $headers[] = 'Cc: ' . sanitize_email($cc);

            }
        }

        /*
        |--------------------------------------------------------------------------
        | BCC
        |--------------------------------------------------------------------------
        */

        if (!empty($payload['bcc'])) {

            foreach ((array) $payload['bcc'] as $bcc) {

                $headers[] = 'Bcc: ' . sanitize_email($bcc);

            }
        }

        /*
        |--------------------------------------------------------------------------
        | Reply-To
        |--------------------------------------------------------------------------
        */

        if (!empty($payload['reply_to'])) {

            $headers[] = 'Reply-To: ' .
                sanitize_email($payload['reply_to']);
        }

        /*
        |--------------------------------------------------------------------------
        | Custom Headers
        |--------------------------------------------------------------------------
        */

        if (!empty($payload['headers'])) {

            foreach ((array) $payload['headers'] as $header) {

                $headers[] = sanitize_text_field($header);

            }
        }

        /*
        |--------------------------------------------------------------------------
        | Attachments
        |--------------------------------------------------------------------------
        */

        $attachments = [];

        if (!empty($payload['attachments'])) {

            foreach ((array) $payload['attachments'] as $file) {

                if (file_exists($file)) {

                    $attachments[] = $file;

                }

            }

        }

        /*
        |--------------------------------------------------------------------------
        | Send
        |--------------------------------------------------------------------------
        */

        $result = wp_mail(
            $to,
            $subject,
            $message,
            $headers,
            $attachments
        );

        MSRA_Utils::log($result);

        $execution = round(
            microtime(true) - $start,
            4
        );

        if ($result) {

            $this->logger->success(
                $payload,
                $execution
            );

            return true;
        }

        global $phpmailer;

        $error = __('Unknown SMTP error.', 'mail-smtp-rest-api');

        if (
            isset($phpmailer) &&
            !empty($phpmailer->ErrorInfo)
        ) {
            $error = $phpmailer->ErrorInfo;
        }

        $this->logger->failed(
            $payload,
            $error,
            $execution
        );

        return false;
    }

    /**
     * Send plain text email.
     *
     * @param string|array $to
     * @param string $subject
     * @param string $message
     * @return bool
     */
    public function text(
        $to,
        string $subject,
        string $message
    ): bool {

        return $this->send([
            'to' => (array) $to,
            'subject' => $subject,
            'message' => $message,
            'html' => false
        ]);
    }

    /**
     * Send HTML email.
     *
     * @param string|array $to
     * @param string $subject
     * @param string $message
     * @return bool
     */
    public function html(
        $to,
        string $subject,
        string $message
    ): bool {

        return $this->send([
            'to' => (array) $to,
            'subject' => $subject,
            'message' => $message,
            'html' => true
        ]);
    }

    /**
     * Queue email.
     *
     * @param array $payload
     * @return bool
     */
    public function queue(array $payload): bool
    {
        $queue = new MSRA_Queue();

        return $queue->add($payload);
    }
}