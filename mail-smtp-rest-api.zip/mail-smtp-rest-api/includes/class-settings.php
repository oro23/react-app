<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Settings
{
    public function __construct()
    {
        add_action(
            'admin_init',
            [$this, 'register']
        );
    }

    public function register(): void
    {
        register_setting(

            'msra_settings_group',

            'msra_settings',

            [
                'sanitize_callback' => [$this, 'sanitize']
            ]

        );
    }

    public function sanitize($input)
    {
        $output = [];

        $output['smtp_host'] = sanitize_text_field(
            $input['smtp_host'] ?? ''
        );

        $output['smtp_port'] = intval(
            $input['smtp_port'] ?? 587
        );

        $output['smtp_username'] = sanitize_text_field(
            $input['smtp_username'] ?? ''
        );

        $output['smtp_password'] = $input['smtp_password'] ?? '';

        $output['smtp_secure'] = sanitize_text_field(
            $input['smtp_secure'] ?? 'tls'
        );

        return $output;
    }
}