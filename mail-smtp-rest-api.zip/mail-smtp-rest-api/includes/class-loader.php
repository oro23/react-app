<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Loader
{
    // public function __construct()
    // {
    //     add_action('plugins_loaded', [$this, 'init']);

    //     add_filter('cron_schedules', [$this, 'cron_schedules']);
    // }

    // public function __construct()
    // {
    //     add_filter('cron_schedules', [$this, 'cron_schedules']);

    //     // 🚀 load SMTP EARLY
    //     new MSRA_SMTP();

    //     add_action('plugins_loaded', [$this, 'init']);
    // }

    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'init']);
    }

    public function init()
    {
        new MSRA_Admin();
        new MSRA_Settings();
        new MSRA_SMTP();
        new MSRA_REST();
        new MSRA_Cron();
    }

    // /**
    //  * Initialize the plugin.
    //  *
    //  * @return void
    //  */
    // public function init(): void
    // {
    //     load_plugin_textdomain(
    //         'mail-smtp-rest-api',
    //         false,
    //         dirname(MSRA_PLUGIN_BASENAME) . '/languages'
    //     );

    //     // Future initialization:
    //     new MSRA_Admin();
    //     new MSRA_Settings();
    //     // new MSRA_SMTP();
    //     new MSRA_REST();
    //     new MSRA_Cron();
    // }

    /**
     * Register custom cron schedules.
     *
     * @param array $schedules Existing schedules.
     * @return array
     */
    public function cron_schedules(array $schedules): array
    {
        if (!isset($schedules['five_minutes'])) {
            $schedules['five_minutes'] = [
                'interval' => 5 * MINUTE_IN_SECONDS,
                'display' => __('Every Five Minutes', 'mail-smtp-rest-api'),
            ];
        }

        return $schedules;
    }
}