<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Rate_Limit
{
    /**
     * Default requests per hour.
     *
     * @var int
     */
    private int $default_limit = 100;

    /**
     * Default time window.
     *
     * @var int
     */
    private int $window = HOUR_IN_SECONDS;

    /**
     * Constructor.
     */
    public function __construct()
    {
    }

    /**
     * Check whether the client is rate limited.
     *
     * @param string $identifier API key or IP address.
     * @return bool
     */
    public function is_limited(string $identifier): bool
    {
        $limit = (int) MSRA_Utils::setting(
            'rate_limit',
            $this->default_limit
        );

        return $this->get_count($identifier) >= $limit;
    }

    /**
     * Increment request counter.
     *
     * @param string $identifier
     * @return int
     */
    public function increment(string $identifier): int
    {
        $key = $this->key($identifier);

        $data = get_transient($key);

        if (!is_array($data)) {

            $data = [
                'count' => 0,
                'start' => time(),
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Reset expired window
        |--------------------------------------------------------------------------
        */

        if ((time() - $data['start']) >= $this->window) {

            $data = [
                'count' => 0,
                'start' => time(),
            ];
        }

        $data['count']++;

        set_transient(
            $key,
            $data,
            $this->window
        );

        return $data['count'];
    }

    /**
     * Get current request count.
     *
     * @param string $identifier
     * @return int
     */
    public function get_count(string $identifier): int
    {
        $data = get_transient(
            $this->key($identifier)
        );

        if (!is_array($data)) {
            return 0;
        }

        if ((time() - $data['start']) >= $this->window) {
            return 0;
        }

        return (int) $data['count'];
    }

    /**
     * Remaining requests.
     *
     * @param string $identifier
     * @return int
     */
    public function remaining(string $identifier): int
    {
        $limit = (int) MSRA_Utils::setting(
            'rate_limit',
            $this->default_limit
        );

        return max(
            0,
            $limit - $this->get_count($identifier)
        );
    }

    /**
     * Seconds until rate limit resets.
     *
     * @param string $identifier
     * @return int
     */
    public function retry_after(string $identifier): int
    {
        $data = get_transient(
            $this->key($identifier)
        );

        if (!is_array($data)) {
            return 0;
        }

        $remaining = $this->window - (time() - $data['start']);

        return max(0, $remaining);
    }

    /**
     * Reset client.
     *
     * @param string $identifier
     * @return bool
     */
    public function reset(string $identifier): bool
    {
        return delete_transient(
            $this->key($identifier)
        );
    }

    /**
     * Check and increment.
     *
     * Returns false when the request is rejected.
     *
     * @param string $identifier
     * @return bool
     */
    public function allow(string $identifier): bool
    {
        if ($this->is_limited($identifier)) {
            return false;
        }

        $this->increment($identifier);

        return true;
    }

    /**
     * Generate transient key.
     *
     * @param string $identifier
     * @return string
     */
    private function key(string $identifier): string
    {
        return 'msra_rl_' . md5($identifier);
    }

    /**
     * Get client IP address.
     *
     * @return string
     */
    public static function client_ip(): string
    {
        $keys = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR',
        ];

        foreach ($keys as $key) {

            if (empty($_SERVER[$key])) {
                continue;
            }

            $ip = explode(',', wp_unslash($_SERVER[$key]))[0];
            $ip = trim($ip);

            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }

        return '0.0.0.0';
    }
}