<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Security
{
    public static function capability()
    {
        return current_user_can(
            'manage_options'
        );
    }

    public static function verify_nonce($nonce, $action)
    {
        return wp_verify_nonce(
            $nonce,
            $action
        );
    }
}