<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Admin
{
    // public function __construct()
    // {
    //     add_action(
    //         'admin_menu',
    //         [$this, 'menu']
    //     );

    //     add_action('admin_notices', [$this, 'show_api_key_notice']);

    //     // add_action('admin_menu', function () {

    //     //     add_menu_page(
    //     //         'Mail SMTP API',
    //     //         'SMTP API',
    //     //         'manage_options',
    //     //         'msra-api',
    //     //         function () {
    //     //             include MSRA_PLUGIN_DIR . 'admin/api-page.php';
    //     //         },
    //     //         'dashicons-email',
    //     //         65
    //     //     );

    //     // });
    // }

    public function __construct()
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'handle_api_actions']);
        add_action('admin_notices', [$this, 'show_api_key_notice']);
    }

    public function handle_api_actions()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (empty($_GET['page']) || $_GET['page'] !== 'msra-api') {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'mail_smtp_api_keys';

        if (isset($_GET['enable'])) {

            check_admin_referer('msra_api_action');

            $id = (int) $_GET['enable'];

            $wpdb->update(
                $table,
                [
                    'status' => 'active'
                ],
                [
                    'id' => $id
                ],
                [
                    '%s'
                ],
                [
                    '%d'
                ]
            );

            wp_safe_redirect(admin_url('admin.php?page=msra-api'));
            exit;
        }

        if (isset($_GET['disable'])) {

            check_admin_referer('msra_api_action');

            $wpdb->update(
                $table,
                ['status' => 'disabled'],
                ['id' => (int) $_GET['disable']],
                ['%s'],
                ['%d']
            );

            wp_safe_redirect(admin_url('admin.php?page=msra-api'));
            exit;
        }

        if (isset($_GET['delete'])) {

            check_admin_referer('msra_api_action');

            $wpdb->delete(
                $table,
                [
                    'id' => (int) $_GET['delete']
                ],
                [
                    '%d'
                ]
            );

            wp_safe_redirect(admin_url('admin.php?page=msra-api'));
            exit;
        }

        error_log('Rows affected: ' . $wpdb->rows_affected);
        error_log('Last error: ' . $wpdb->last_error);
    }

    /**
     * Register admin menu
     */
    // public function register_menu(): void
    // {
    //     add_menu_page(
    //         'Mail SMTP API',
    //         'SMTP API',
    //         'manage_options',
    //         'msra-api',
    //         [$this, 'render_api_page'],
    //         'dashicons-email-alt',
    //         65
    //     );
    // }

    /**
     * Render API page
     */
    // public function render_api_page(): void
    // {
    //     include MSRA_PLUGIN_DIR . 'admin/api-page.php';
    // }

    public function menu(): void
    {
        add_menu_page(
            __('Mail SMTP', 'mail-smtp-rest-api'),
            __('Mail SMTP', 'mail-smtp-rest-api'),
            'manage_options',
            'msra',
            [$this, 'dashboard'],
            'dashicons-email-alt',
            58
        );

        add_submenu_page(
            'msra',
            'SMTP Settings',
            'SMTP Settings',
            'manage_options',
            'msra-settings',
            [$this, 'settings']
        );

        add_submenu_page(
            'msra',
            'REST API',
            'REST API',
            'manage_options',
            'msra-api',
            [$this, 'api']
        );

        add_submenu_page(
            'msra',
            'Logs',
            'Logs',
            'manage_options',
            'msra-logs',
            [$this, 'logs']
        );

        add_submenu_page(
            'msra',
            'Queue',
            'Queue',
            'manage_options',
            'msra-queue',
            [$this, 'queue']
        );
    }

    public function dashboard()
    {
        echo "<div class='wrap'><h1>Mail SMTP REST API</h1></div>";
    }

    public function settings()
    {
        include MSRA_PLUGIN_DIR . 'admin/settings-page.php';
    }

    public function api()
    {
        include MSRA_PLUGIN_DIR . 'admin/api-page.php';
    }

    public function logs()
    {
        include MSRA_PLUGIN_DIR . 'admin/logs-page.php';
    }

    public function queue()
    {
        include MSRA_PLUGIN_DIR . 'admin/queue-page.php';
    }



    public function show_api_key_notice(): void
    {
        $key = get_option('msra_default_api_key');

        if (!$key) {
            return;
        }

        echo '<div class="notice notice-success is-dismissible"><p>';
        echo '<strong>Mail SMTP REST API:</strong> Your API Key is: ';
        echo '<code>' . esc_html($key) . '</code>';
        echo '</p></div>';

        delete_option('msra_default_api_key');
    }
}