<?php

if (!defined('ABSPATH')) {
    exit;
}

class MSRA_Queue
{
    /**
     * Queue table.
     *
     * @var string
     */
    private string $table;

    /**
     * Constructor.
     */
    public function __construct()
    {
        global $wpdb;

        $this->table = $wpdb->prefix . 'mail_smtp_queue';
    }

    /**
     * Add an email to the queue.
     *
     * @param array $payload
     * @return bool
     */
    public function add(array $payload): bool
    {
        global $wpdb;

        $result = $wpdb->insert(
            $this->table,
            [
                'payload' => wp_json_encode($payload),
                'attempts' => 0,
                'status' => 'pending',
                'next_retry' => null,
                'created_at' => current_time('mysql'),
            ],
            [
                '%s',
                '%d',
                '%s',
                '%s',
                '%s',
            ]
        );

        if ($result) {
            (new MSRA_Logger())->queued($payload);
        }

        return $result !== false;
    }

    /**
     * Get queued item.
     *
     * @param int $id
     * @return object|null
     */
    public function get(int $id)
    {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$this->table}
                 WHERE id=%d",
                $id
            )
        );
    }

    /**
     * Get pending emails.
     *
     * @param int $limit
     * @return array
     */
    public function pending(int $limit = 20): array
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$this->table}
                 WHERE status=%s
                 ORDER BY id ASC
                 LIMIT %d",
                'pending',
                $limit
            )
        );
    }

    /**
     * Mark queue item as processing.
     *
     * @param int $id
     * @return bool
     */
    public function processing(int $id): bool
    {
        return $this->update_status($id, 'processing');
    }

    /**
     * Mark queue item as completed.
     *
     * @param int $id
     * @return bool
     */
    public function completed(int $id): bool
    {
        return $this->update_status($id, 'completed');
    }

    /**
     * Mark queue item as failed.
     *
     * @param int $id
     * @return bool
     */
    public function failed(int $id): bool
    {
        return $this->update_status($id, 'failed');
    }

    /**
     * Update queue status.
     *
     * @param int $id
     * @param string $status
     * @return bool
     */
    public function update_status(
        int $id,
        string $status
    ): bool {

        global $wpdb;

        $updated = $wpdb->update(
            $this->table,
            [
                'status' => sanitize_text_field($status),
            ],
            [
                'id' => $id,
            ],
            [
                '%s',
            ],
            [
                '%d',
            ]
        );

        return $updated !== false;
    }

    /**
     * Increment retry attempts.
     *
     * @param int $id
     * @return bool
     */
    public function increment_attempts(int $id): bool
    {
        global $wpdb;

        $item = $this->get($id);

        if (!$item) {
            return false;
        }

        $updated = $wpdb->update(
            $this->table,
            [
                'attempts' => ((int) $item->attempts) + 1,
            ],
            [
                'id' => $id,
            ],
            [
                '%d',
            ],
            [
                '%d',
            ]
        );

        return $updated !== false;
    }

    /**
     * Set next retry time.
     *
     * @param int $id
     * @param int $minutes
     * @return bool
     */
    public function set_next_retry(
        int $id,
        int $minutes = 5
    ): bool {

        global $wpdb;

        $retry = gmdate(
            'Y-m-d H:i:s',
            time() + ($minutes * MINUTE_IN_SECONDS)
        );

        $updated = $wpdb->update(
            $this->table,
            [
                'next_retry' => $retry,
            ],
            [
                'id' => $id,
            ],
            [
                '%s',
            ],
            [
                '%d',
            ]
        );

        return $updated !== false;
    }

    /**
     * Delete queue item.
     *
     * @param int $id
     * @return bool
     */
    public function delete(int $id): bool
    {
        global $wpdb;

        $deleted = $wpdb->delete(
            $this->table,
            [
                'id' => $id,
            ],
            [
                '%d',
            ]
        );

        return $deleted !== false;
    }

    /**
     * Clear completed emails.
     *
     * @return bool
     */
    public function clear_completed(): bool
    {
        global $wpdb;

        $result = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table}
                 WHERE status=%s",
                'completed'
            )
        );

        return $result !== false;
    }

    /**
     * Clear failed emails.
     *
     * @return bool
     */
    public function clear_failed(): bool
    {
        global $wpdb;

        $result = $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$this->table}
                 WHERE status=%s",
                'failed'
            )
        );

        return $result !== false;
    }

    /**
     * Queue statistics.
     *
     * @return array
     */
    public function stats(): array
    {
        global $wpdb;

        return [
            'total' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$this->table}"
            ),

            'pending' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table} WHERE status=%s",
                    'pending'
                )
            ),

            'processing' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table} WHERE status=%s",
                    'processing'
                )
            ),

            'completed' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table} WHERE status=%s",
                    'completed'
                )
            ),

            'failed' => (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$this->table} WHERE status=%s",
                    'failed'
                )
            ),
        ];
    }
}