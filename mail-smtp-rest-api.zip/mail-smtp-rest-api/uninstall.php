<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

delete_option('msra_settings');
delete_option('msra_version');

/*
Leave log tables by default.

Later we'll add:

Delete data on uninstall

Checkbox in settings

GDPR support
*/