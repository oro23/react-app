<?php

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

$table = $wpdb->prefix . 'mail_smtp_logs';

$per_page = 20;
$page = max(1, absint($_GET['paged'] ?? 1));
$offset = ($page - 1) * $per_page;

$search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
$status = isset($_GET['status']) ? sanitize_text_field(wp_unslash($_GET['status'])) : '';

$where = ' WHERE 1=1 ';
$params = [];

if ($search !== '') {
    $where .= " AND (to_email LIKE %s OR subject LIKE %s)";
    $like = '%' . $wpdb->esc_like($search) . '%';
    $params[] = $like;
    $params[] = $like;
}

if ($status !== '') {
    $where .= " AND status = %s";
    $params[] = $status;
}

$count_sql = "SELECT COUNT(*) FROM {$table} {$where}";

if (!empty($params)) {
    $count_sql = $wpdb->prepare($count_sql, $params);
}

$total = (int) $wpdb->get_var($count_sql);

$list_sql = "SELECT *
             FROM {$table}
             {$where}
             ORDER BY id DESC
             LIMIT %d OFFSET %d";

$list_params = $params;
$list_params[] = $per_page;
$list_params[] = $offset;

$list_sql = $wpdb->prepare($list_sql, $list_params);

$logs = $wpdb->get_results($list_sql);

$total_pages = max(1, ceil($total / $per_page));

?>

<div class="wrap">

    <h1 class="wp-heading-inline">
        <?php esc_html_e('Email Logs', 'mail-smtp-rest-api'); ?>
    </h1>

    <hr class="wp-header-end">

    <form method="get">

        <input type="hidden" name="page" value="msra-logs">

        <p class="search-box">

            <input type="search" name="s" value="<?php echo esc_attr($search); ?>"
                placeholder="<?php esc_attr_e('Search recipient or subject', 'mail-smtp-rest-api'); ?>">

            <select name="status">

                <option value="">
                    <?php esc_html_e('All Statuses', 'mail-smtp-rest-api'); ?>
                </option>

                <option value="success" <?php selected($status, 'success'); ?>>
                    Success
                </option>

                <option value="failed" <?php selected($status, 'failed'); ?>>
                    Failed
                </option>

                <option value="queued" <?php selected($status, 'queued'); ?>>
                    Queued
                </option>

            </select>

            <?php submit_button(__('Filter', 'mail-smtp-rest-api'), '', '', false); ?>

        </p>

    </form>

    <table class="widefat striped">

        <thead>

            <tr>

                <th width="60">#</th>

                <th>
                    <?php esc_html_e('Recipient', 'mail-smtp-rest-api'); ?>
                </th>

                <th>
                    <?php esc_html_e('Subject', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="100">
                    <?php esc_html_e('Status', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="110">
                    <?php esc_html_e('Time', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="170">
                    <?php esc_html_e('Date', 'mail-smtp-rest-api'); ?>
                </th>

            </tr>

        </thead>

        <tbody>

            <?php if (empty($logs)): ?>

                <tr>

                    <td colspan="6">

                        <?php esc_html_e('No email logs found.', 'mail-smtp-rest-api'); ?>

                    </td>

                </tr>

            <?php else: ?>

                <?php foreach ($logs as $log): ?>

                    <tr>

                        <td>

                            <?php echo (int) $log->id; ?>

                        </td>

                        <td>

                            <?php echo esc_html($log->to_email); ?>

                        </td>

                        <td>

                            <?php echo esc_html($log->subject); ?>

                        </td>

                        <td>

                            <?php

                            switch ($log->status) {

                                case 'success':
                                    echo '<span style="color:green;font-weight:bold;">Success</span>';
                                    break;

                                case 'failed':
                                    echo '<span style="color:red;font-weight:bold;">Failed</span>';
                                    break;

                                case 'queued':
                                    echo '<span style="color:#dba617;font-weight:bold;">Queued</span>';
                                    break;

                                default:
                                    echo esc_html($log->status);

                            }

                            ?>

                        </td>

                        <td>

                            <?php

                            if (isset($log->execution_time)) {
                                echo esc_html(number_format((float) $log->execution_time, 3)) . ' s';
                            }

                            ?>

                        </td>

                        <td>

                            <?php

                            echo esc_html(
                                wp_date(
                                    get_option('date_format') . ' ' . get_option('time_format'),
                                    strtotime($log->created_at)
                                )
                            );

                            ?>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

        </tbody>

    </table>

    <?php if ($total_pages > 1): ?>

        <div class="tablenav">

            <div class="tablenav-pages">

                <?php

                echo wp_kses_post(

                    paginate_links([

                        'base' => add_query_arg('paged', '%#%'),

                        'format' => '',

                        'current' => $page,

                        'total' => $total_pages,

                        'prev_text' => '&laquo;',

                        'next_text' => '&raquo;',

                    ])

                );

                ?>

            </div>

        </div>

    <?php endif; ?>

    <p>

        <strong>

            <?php
            printf(
                esc_html__('Total Logs: %d', 'mail-smtp-rest-api'),
                $total
            );
            ?>

        </strong>

    </p>

</div>