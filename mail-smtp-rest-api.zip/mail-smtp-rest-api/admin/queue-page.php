<?php

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

$table = $wpdb->prefix . 'mail_smtp_queue';

$per_page = 20;
$page = max(1, absint($_GET['paged'] ?? 1));
$offset = ($page - 1) * $per_page;

$search = isset($_GET['s'])
    ? sanitize_text_field(wp_unslash($_GET['s']))
    : '';

$status = isset($_GET['status'])
    ? sanitize_text_field(wp_unslash($_GET['status']))
    : '';

$where = ' WHERE 1=1 ';
$params = [];

if ($status !== '') {
    $where .= ' AND status = %s';
    $params[] = $status;
}

if ($search !== '') {

    $where .= ' AND payload LIKE %s';

    $params[] = '%' . $wpdb->esc_like($search) . '%';
}

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$total_items = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}");

$total_pending = (int) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE status=%s",
        'pending'
    )
);

$total_processing = (int) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE status=%s",
        'processing'
    )
);

$total_failed = (int) $wpdb->get_var(
    $wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE status=%s",
        'failed'
    )
);

/*
|--------------------------------------------------------------------------
| Count
|--------------------------------------------------------------------------
*/

$count_sql = "SELECT COUNT(*) FROM {$table} {$where}";

if (!empty($params)) {
    $count_sql = $wpdb->prepare($count_sql, $params);
}

$total = (int) $wpdb->get_var($count_sql);

/*
|--------------------------------------------------------------------------
| Queue
|--------------------------------------------------------------------------
*/

$list_sql = "
SELECT *
FROM {$table}
{$where}
ORDER BY id DESC
LIMIT %d OFFSET %d
";

$list_params = $params;
$list_params[] = $per_page;
$list_params[] = $offset;

$list_sql = $wpdb->prepare($list_sql, $list_params);

$items = $wpdb->get_results($list_sql);

$total_pages = max(1, ceil($total / $per_page));

?>

<div class="wrap">

    <h1 class="wp-heading-inline">
        <?php esc_html_e('Email Queue', 'mail-smtp-rest-api'); ?>
    </h1>

    <hr class="wp-header-end">

    <table class="widefat striped" style="max-width:700px;margin-bottom:25px;">
        <tbody>

            <tr>

                <th width="250">
                    <?php esc_html_e('Total Queue', 'mail-smtp-rest-api'); ?>
                </th>

                <td>
                    <?php echo esc_html($total_items); ?>
                </td>

            </tr>

            <tr>

                <th>
                    <?php esc_html_e('Pending', 'mail-smtp-rest-api'); ?>
                </th>

                <td>
                    <span style="color:#dba617;font-weight:bold;">
                        <?php echo esc_html($total_pending); ?>
                    </span>
                </td>

            </tr>

            <tr>

                <th>
                    <?php esc_html_e('Processing', 'mail-smtp-rest-api'); ?>
                </th>

                <td>
                    <span style="color:#2271b1;font-weight:bold;">
                        <?php echo esc_html($total_processing); ?>
                    </span>
                </td>

            </tr>

            <tr>

                <th>
                    <?php esc_html_e('Failed', 'mail-smtp-rest-api'); ?>
                </th>

                <td>
                    <span style="color:red;font-weight:bold;">
                        <?php echo esc_html($total_failed); ?>
                    </span>
                </td>

            </tr>

        </tbody>
    </table>

    <form method="get">

        <input type="hidden" name="page" value="msra-queue">

        <p class="search-box">

            <input type="search" name="s" value="<?php echo esc_attr($search); ?>"
                placeholder="<?php esc_attr_e('Search payload...', 'mail-smtp-rest-api'); ?>">

            <select name="status">

                <option value="">
                    <?php esc_html_e('All Status', 'mail-smtp-rest-api'); ?>
                </option>

                <option value="pending" <?php selected($status, 'pending'); ?>>
                    Pending
                </option>

                <option value="processing" <?php selected($status, 'processing'); ?>>
                    Processing
                </option>

                <option value="failed" <?php selected($status, 'failed'); ?>>
                    Failed
                </option>

                <option value="completed" <?php selected($status, 'completed'); ?>>
                    Completed
                </option>

            </select>

            <?php submit_button(__('Filter', 'mail-smtp-rest-api'), '', '', false); ?>

        </p>

    </form>

    <table class="widefat striped">

        <thead>

            <tr>

                <th width="70">ID</th>

                <th>
                    <?php esc_html_e('Payload', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="100">
                    <?php esc_html_e('Attempts', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="120">
                    <?php esc_html_e('Status', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="180">
                    <?php esc_html_e('Next Retry', 'mail-smtp-rest-api'); ?>
                </th>

                <th width="180">
                    <?php esc_html_e('Created', 'mail-smtp-rest-api'); ?>
                </th>

            </tr>

        </thead>

        <tbody>

            <?php if (empty($items)): ?>

                <tr>

                    <td colspan="6">

                        <?php esc_html_e('Queue is empty.', 'mail-smtp-rest-api'); ?>

                    </td>

                </tr>

            <?php else: ?>

                <?php foreach ($items as $item): ?>

                    <tr>

                        <td>

                            <?php echo (int) $item->id; ?>

                        </td>

                        <td>

                            <textarea readonly rows="3"
                                style="width:100%;resize:vertical;"><?php echo esc_textarea($item->payload); ?></textarea>

                        </td>

                        <td>

                            <?php echo (int) $item->attempts; ?>

                        </td>

                        <td>

                            <?php

                            switch ($item->status) {

                                case 'pending':
                                    echo '<span style="color:#dba617;font-weight:bold;">Pending</span>';
                                    break;

                                case 'processing':
                                    echo '<span style="color:#2271b1;font-weight:bold;">Processing</span>';
                                    break;

                                case 'completed':
                                    echo '<span style="color:green;font-weight:bold;">Completed</span>';
                                    break;

                                case 'failed':
                                    echo '<span style="color:red;font-weight:bold;">Failed</span>';
                                    break;

                                default:
                                    echo esc_html($item->status);

                            }

                            ?>

                        </td>

                        <td>

                            <?php

                            if (!empty($item->next_retry)) {

                                echo esc_html(
                                    wp_date(
                                        get_option('date_format') . ' ' .
                                        get_option('time_format'),
                                        strtotime($item->next_retry)
                                    )
                                );

                            } else {

                                echo '&mdash;';

                            }

                            ?>

                        </td>

                        <td>

                            <?php

                            echo esc_html(
                                wp_date(
                                    get_option('date_format') . ' ' .
                                    get_option('time_format'),
                                    strtotime($item->created_at)
                                )
                            );

                            ?>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

        </tbody>

    </table>

    <?php if ($total_pages > 1): ?>

        <div class="tablenav">

            <div class="tablenav-pages">

                <?php

                echo wp_kses_post(

                    paginate_links([

                        'base' => add_query_arg('paged', '%#%'),

                        'format' => '',

                        'current' => $page,

                        'total' => $total_pages,

                        'prev_text' => '&laquo;',

                        'next_text' => '&raquo;',

                    ])

                );

                ?>

            </div>

        </div>

    <?php endif; ?>

</div>