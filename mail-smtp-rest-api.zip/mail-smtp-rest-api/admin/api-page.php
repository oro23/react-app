<?php

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;

$table = $wpdb->prefix . 'mail_smtp_api_keys';

/**
 * CREATE KEY
 */
if (isset($_POST['msra_create_key'])) {

    check_admin_referer('msra_create_key_action');

    $name = sanitize_text_field($_POST['name']);

    if (!empty($name)) {

        $raw_key = 'msra_' . bin2hex(random_bytes(24));

        $hash = password_hash($raw_key, PASSWORD_DEFAULT);

        $wpdb->insert(
            $table,
            [
                'name' => $name,
                'api_key_hash' => $hash,
                'status' => 1,
                'created_at' => current_time('mysql')
            ]
        );

        update_option('msra_new_api_key', $raw_key);
    }
}

/**
 * DELETE KEY
 */
if (isset($_GET['delete'])) {

    $wpdb->delete(
        $table,
        [
            'id' => (int) $_GET['delete']
        ],
        [
            '%d'
        ]
    );

    wp_safe_redirect(admin_url('admin.php?page=msra-api'));
    exit;
}

/**
 * DISABLE KEY
 */
if (isset($_GET['disable'])) {

    $wpdb->update(
        $table,
        [
            'status' => 'disabled'
        ],
        [
            'id' => (int) $_GET['disable']
        ],
        [
            '%s'
        ],
        [
            '%d'
        ]
    );

    wp_safe_redirect(admin_url('admin.php?page=msra-api&disable=1'));
    exit;
}

/**
 * ENABLE KEY
 */
if (isset($_GET['enable'])) {

    $wpdb->update(
        $table,
        [
            'status' => 'active'
        ],
        [
            'id' => (int) $_GET['enable']
        ],
        [
            '%s'
        ],
        [
            '%d'
        ]
    );

    wp_safe_redirect(admin_url('admin.php?page=msra-api'));
    exit;
}

$keys = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
?>

<div class="wrap">
    <h1>API Keys</h1>

    <!-- CREATE KEY FORM -->
    <form method="post">
        <?php wp_nonce_field('msra_create_key_action'); ?>

        <input type="text" name="name" placeholder="Key Name" required>

        <button type="submit" name="msra_create_key" class="button button-primary">
            Create Key
        </button>
    </form>

    <hr>

    <!-- SHOW NEW KEY ONCE -->
    <?php if ($new_key = get_option('msra_new_api_key')): ?>
        <div class="notice notice-success">
            <p><strong>Your API Key (save it now):</strong></p>
            <code><?php echo esc_html($new_key); ?></code>
        </div>
        <?php delete_option('msra_new_api_key'); ?>
    <?php endif; ?>

    <!-- TABLE -->
    <table class="widefat striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Status</th>
                <th>Last Used</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php if (!empty($keys)): ?>
                <?php foreach ($keys as $key): ?>

                    <tr>

                        <td><?php echo (int) $key->id; ?></td>

                        <td><?php echo esc_html($key->name); ?></td>

                        <td>
                            <?php if ($key->status === 'active'): ?>

                                <span style="color:#008a20;font-weight:600;">
                                    Active
                                </span>

                            <?php else: ?>

                                <span style="color:#d63638;font-weight:600;">
                                    Disabled
                                </span>

                            <?php endif; ?>
                            <!-- <?php echo $key->status ? 'Active' : 'Disabled'; ?> -->
                        </td>

                        <td>
                            <?php
                            echo !empty($key->last_used)
                                ? esc_html($key->last_used)
                                : '—';
                            ?>
                        </td>

                        <td>

                            <?php if ($key->status === 'active'): ?>

                                <a class="button button-secondary" href="<?php echo esc_url(
                                    wp_nonce_url(
                                        admin_url('admin.php?page=msra-api&disable=' . (int) $key->id),
                                        'msra_api_action'
                                    )
                                ); ?>">
                                    Disable
                                </a>

                            <?php else: ?>

                                <a class="button button-primary" href="<?php echo esc_url(
                                    wp_nonce_url(
                                        admin_url('admin.php?page=msra-api&enable=' . (int) $key->id),
                                        'msra_api_action'
                                    )
                                ); ?>">
                                    Enable
                                </a>

                            <?php endif; ?>

                            <a class="button button-link-delete"
                                href="<?php echo esc_url(admin_url('admin.php?page=msra-api&delete=' . $key->id)); ?>"
                                onclick="return confirm('Are you sure you want to delete this API key?');">
                                Delete
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php else: ?>

                <tr>
                    <td colspan="5">
                        No API keys found.
                    </td>
                </tr>

            <?php endif; ?>
        </tbody>
    </table>

    <hr>

    <h2>REST API Info</h2>

    <p><strong>Namespace:</strong> mail-smtp/v1</p>
    <p><strong>Endpoint:</strong> <?php echo esc_html(rest_url('mail-smtp/v1/send')); ?></p>
    <p><strong>Method:</strong> POST</p>
    <p><strong>Auth Header:</strong> X-API-KEY</p>
</div>


<div class="wrap">

    <h1><?php esc_html_e('Mail SMTP REST API', 'mail-smtp-rest-api'); ?></h1>

    <p>
        <?php esc_html_e('Use the REST API to send emails securely from external applications.', 'mail-smtp-rest-api'); ?>
    </p>

    <hr>

    <h2><?php esc_html_e('REST API Information', 'mail-smtp-rest-api'); ?></h2>

    <table class="widefat striped">
        <tbody>

            <tr>
                <th width="220">
                    <?php esc_html_e('REST Namespace', 'mail-smtp-rest-api'); ?>
                </th>
                <td>
                    <code>mail-smtp/v1</code>
                </td>
            </tr>

            <tr>
                <th>
                    <?php esc_html_e('Endpoint', 'mail-smtp-rest-api'); ?>
                </th>
                <td>
                    <code><?php echo esc_html($rest_url . 'send'); ?></code>
                </td>
            </tr>

            <tr>
                <th>
                    <?php esc_html_e('Method', 'mail-smtp-rest-api'); ?>
                </th>
                <td>
                    POST
                </td>
            </tr>

            <tr>
                <th>
                    <?php esc_html_e('Authentication', 'mail-smtp-rest-api'); ?>
                </th>
                <td>
                    <code>X-API-KEY</code>
                </td>
            </tr>

            <tr>
                <th>
                    <?php esc_html_e('Content Type', 'mail-smtp-rest-api'); ?>
                </th>
                <td>
                    <code>application/json</code>
                </td>
            </tr>

        </tbody>
    </table>

    <br>

    <h2><?php esc_html_e('Request Headers', 'mail-smtp-rest-api'); ?></h2>

    <pre>{
    "Content-Type": "application/json",
    "X-API-KEY": "YOUR_API_KEY"
}</pre>

    <h2><?php esc_html_e('JSON Request Example', 'mail-smtp-rest-api'); ?></h2>

    <pre>{
    "to": [
        "john@example.com"
    ],
    "cc": [],
    "bcc": [],
    "subject": "Hello World",
    "message": "&lt;h1&gt;Hello&lt;/h1&gt;",
    "html": true,
    "attachments": []
}</pre>

    <h2><?php esc_html_e('cURL Example', 'mail-smtp-rest-api'); ?></h2>

    <pre>curl -X POST "<?php echo esc_html($rest_url . 'send'); ?>" \
-H "Content-Type: application/json" \
-H "X-API-KEY: YOUR_API_KEY" \
-d '{
    "to":["admin@example.com"],
    "subject":"Test Email",
    "message":"Hello from REST API",
    "html":true
}'</pre>

    <hr>

    <h2><?php esc_html_e('API Keys', 'mail-smtp-rest-api'); ?></h2>

    <p>
        <?php esc_html_e('API key management will be available after implementing the authentication module.', 'mail-smtp-rest-api'); ?>
    </p>

    <?php if (empty($api_keys)): ?>

        <div class="notice notice-warning inline">
            <p>
                <?php esc_html_e('No API Keys have been created yet.', 'mail-smtp-rest-api'); ?>
            </p>
        </div>

    <?php else: ?>

        <table class="widefat striped">

            <thead>

                <tr>
                    <th><?php esc_html_e('Name', 'mail-smtp-rest-api'); ?></th>
                    <th><?php esc_html_e('Last Used', 'mail-smtp-rest-api'); ?></th>
                    <th><?php esc_html_e('Status', 'mail-smtp-rest-api'); ?></th>
                </tr>

            </thead>

            <tbody>

                <?php foreach ($api_keys as $key): ?>

                    <tr>

                        <td><?php echo esc_html($key['name'] ?? ''); ?></td>

                        <td><?php echo esc_html($key['last_used'] ?? '-'); ?></td>

                        <td>

                            <?php
                            echo !empty($key['status'])
                                ? '<span style="color:green;font-weight:bold;">Active</span>'
                                : '<span style="color:red;font-weight:bold;">Disabled</span>';
                            ?>

                        </td>

                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    <?php endif; ?>

    <br>

    <button class="button button-primary" disabled>
        <?php esc_html_e('Generate API Key (Coming Soon)', 'mail-smtp-rest-api'); ?>
    </button>

    <hr>

    <h2><?php esc_html_e('Security Notes', 'mail-smtp-rest-api'); ?></h2>

    <ul style="list-style:disc;padding-left:20px;">

        <li><?php esc_html_e('Never expose your API key publicly.', 'mail-smtp-rest-api'); ?></li>

        <li><?php esc_html_e('Always send requests over HTTPS.', 'mail-smtp-rest-api'); ?></li>

        <li><?php esc_html_e('Store API keys securely in your applications.', 'mail-smtp-rest-api'); ?></li>

        <li><?php esc_html_e('Rotate API keys periodically.', 'mail-smtp-rest-api'); ?></li>

        <li><?php esc_html_e('Rate limiting and request logging will be enabled after the REST module is implemented.', 'mail-smtp-rest-api'); ?>
        </li>

    </ul>

</div>