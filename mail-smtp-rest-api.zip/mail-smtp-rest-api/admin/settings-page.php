<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * SAVE SETTINGS
 */
if (isset($_POST['msra_save_settings'])) {

    update_option('msra_smtp_host', sanitize_text_field($_POST['msra_smtp_host']));
    update_option('msra_smtp_port', sanitize_text_field($_POST['msra_smtp_port']));
    update_option('msra_smtp_username', sanitize_text_field($_POST['msra_smtp_username']));

    update_option('msra_smtp_password', sanitize_text_field($_POST['msra_smtp_password']));

    update_option('msra_smtp_encryption', sanitize_text_field($_POST['msra_smtp_encryption']));
    update_option('msra_from_email', sanitize_email($_POST['msra_from_email']));
    update_option('msra_from_name', sanitize_text_field($_POST['msra_from_name']));

    echo '<div class="notice notice-success"><p>Settings saved successfully.</p></div>';
}
?>

<div class="wrap">
    <h1>SMTP Settings</h1>

    <form method="post">

        <table class="form-table">

            <tr>
                <th>SMTP Host</th>
                <td>
                    <input type="text" name="msra_smtp_host" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_smtp_host')); ?>">
                </td>
            </tr>

            <tr>
                <th>SMTP Port</th>
                <td>
                    <input type="number" name="msra_smtp_port" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_smtp_port', 587)); ?>">
                </td>
            </tr>

            <tr>
                <th>SMTP Username</th>
                <td>
                    <input type="text" name="msra_smtp_username" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_smtp_username')); ?>">
                </td>
            </tr>

            <tr>
                <th>SMTP Password</th>
                <td>
                    <input type="password" name="msra_smtp_password" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_smtp_password')); ?>">
                </td>
            </tr>

            <tr>
                <th>Encryption</th>
                <td>
                    <select name="msra_smtp_encryption">

                        <option value="tls" <?php selected(get_option('msra_smtp_encryption'), 'tls'); ?>>
                            TLS
                        </option>

                        <option value="ssl" <?php selected(get_option('msra_smtp_encryption'), 'ssl'); ?>>
                            SSL
                        </option>

                        <option value="" <?php selected(get_option('msra_smtp_encryption'), ''); ?>>
                            None
                        </option>

                    </select>
                </td>
            </tr>

            <tr>
                <th>From Email</th>
                <td>
                    <input type="email" name="msra_from_email" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_from_email')); ?>">
                </td>
            </tr>

            <tr>
                <th>From Name</th>
                <td>
                    <input type="text" name="msra_from_name" class="regular-text"
                        value="<?php echo esc_attr(get_option('msra_from_name')); ?>">
                </td>
            </tr>

        </table>

        <p>
            <button type="submit" name="msra_save_settings" class="button button-primary">
                Save Settings
            </button>
        </p>

    </form>
</div>