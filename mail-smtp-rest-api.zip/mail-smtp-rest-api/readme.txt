# Mail SMTP REST API

Production-ready SMTP plugin with REST API support.

Current Version: 1.0.0