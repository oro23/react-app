<?php
/**
 * Plugin Name: Mail SMTP REST API
 * Description: SMTP Mail Plugin with REST API
 * Version: 1.0.0
 * Author: LucKY
 * Text Domain: mail-smtp-rest-api
 */

if (!defined('ABSPATH')) {
    exit;
}

define('MSRA_VERSION', '1.0.0');
define('MSRA_PLUGIN_FILE', __FILE__);
define('MSRA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MSRA_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MSRA_PLUGIN_BASENAME', plugin_basename(__FILE__));

require_once MSRA_PLUGIN_DIR . 'includes/class-autoloader.php';
MSRA_Autoloader::register();

/*
|--------------------------------------------------------------------------
| Activation
|--------------------------------------------------------------------------
*/

register_activation_hook(
    __FILE__,
    ['MSRA_Activator', 'activate']
);

register_deactivation_hook(
    __FILE__,
    ['MSRA_Deactivator', 'deactivate']
);

/*
|--------------------------------------------------------------------------
| Bootstrap
|--------------------------------------------------------------------------
*/

MSRA_Plugin::instance();


// add_action('muplugins_loaded', function () {
//     new MSRA_SMTP();
// });

// add_action('plugins_loaded', function () {
//     MSRA_Plugin::instance();
// });

// add_action('wp_mail_failed', function ($error) {
//     error_log('MSRA WP_MAIL_FAILED: ' . print_r($error, true));
// });

// add_filter('wp_mail_from', function ($email) {

//     $custom = get_option('msra_from_email');

//     if (!empty($custom) && is_email($custom)) {
//         return $custom;
//     }

//     return 'no-reply@' . parse_url(home_url(), PHP_URL_HOST);
// });

// add_filter('wp_mail_from_name', function ($name) {

//     $custom = get_option('msra_from_name');

//     return !empty($custom)
//         ? $custom
//         : get_bloginfo('name');
// });